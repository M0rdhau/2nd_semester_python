# Simple radius calculator...
# *circlinator*



*for TalTech, 2021*